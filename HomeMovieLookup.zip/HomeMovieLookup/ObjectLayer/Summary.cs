﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieEntityLayer
{
    public class Summary
    {
        public string Plot{ get; set; }
    }
}
