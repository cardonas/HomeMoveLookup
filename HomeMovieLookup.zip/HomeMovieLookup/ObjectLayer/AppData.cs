﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieEntityLayer
{
    public class AppData
    {
        public static string DataPath { get; set; }
        public static readonly string MovieListFileName = "movielist.csv";
    }
}
