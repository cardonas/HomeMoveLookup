﻿using MovieDataAccessLayer;
using MovieEntityLayer;
using System;
using System.Collections.Generic;
using System.Text;

namespace MovieControlLayer
{
    public class MovieManager
    {
        List<Movie> _movieList;
        public MovieManager()
        {
            try
            {
                _movieList = MovieDataAccessor.RetrieveMovieList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public List<Movie> MovieLIst
        {
            get { return _movieList;}
        }
        public Summary FetchMoviePlot(int movieIndex)
        {
            try
            {
                return MovieDataAccessor.RetrievePlot(_movieList[movieIndex]);
            }
            catch(Exception)
            {
                throw new ApplicationException("Plot not Available");
            }
        }

        public List<Movie> AddMovie(Movie movie, Summary plot)
        {
            try
            {
                if(MovieDataAccessor.AddMovie(movie, plot))
                {
                    _movieList = MovieDataAccessor.RetrieveMovieList();
                }
                return _movieList;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
