﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using MovieEntityLayer;

namespace MovieDataAccessLayer
{
    public class MovieDataAccessor
    {
        public static List<Movie> RetrieveMovieList()
        {
            List<Movie> movieList = new List<Movie>();

            char[] seperator = { ',' };
            try
            {
                StreamReader reader = new StreamReader("C:\\Users\\cardo\\iCloudDrive\\Desktop\\Net Programming\\Project\\HomeMovieLookup\\HomeMovieLookup\\moviedata\\movielist.csv");
                while (reader.EndOfStream == false)
                {
                    string line = reader.ReadLine();
                    string[] parts;
                    if (line.Length > 16)
                    {
                        parts = line.Split(seperator);
                        if (parts.Count() == 6)
                        {
                            Movie newMovie = new Movie();
                            newMovie.ImdbID = parts[0];
                            newMovie.Title = parts[1];
                            newMovie.Released = parts[2];
                            newMovie.Genre = parts[3];
                            newMovie.PlotFileName = parts[4];
                            newMovie.PosterFileName = parts[4];

                            movieList.Add(newMovie);
                        }
                    }
                }
                reader.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return movieList;
        }


        public static Summary RetrievePlot(Movie movie)
        {
            Summary newPlot = new Summary();
            try
            {
                StreamReader fileReader = new StreamReader(AppData.DataPath + @"\" + movie.PlotFileName);
                newPlot.Plot = fileReader.ReadToEnd();
                fileReader.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return newPlot;
        }

        public static bool UpdateFriut(int movieIndex, Summary plot, List<Movie> movieList)
        {
            try
            {
                StreamWriter fileWriter = new StreamWriter(AppData.DataPath + @"\" + movieList[movieIndex].PlotFileName);
                fileWriter.WriteLine(plot.Plot);
                fileWriter.Close();

                StreamWriter fileWriter2 = new StreamWriter(AppData.DataPath + @"\" + AppData.MovieListFileName);
                foreach (Movie movie in movieList)
                {
                    fileWriter2.WriteLine(movie.ImdbID + ", " +
                        movie.Title + ", " +
                        movie.Released + ", " +
                        movie.Genre + ", " +
                        movie.PlotFileName + ", " +
                        movie.PosterFileName);
                }
                fileWriter.Close();
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }

        public static bool AddMovie(Movie movie, Summary plot)
        {
            try
            {
                StreamWriter fileWriter = new StreamWriter(AppData.DataPath + @"\" + movie.PlotFileName);
                fileWriter.WriteLine(plot.Plot);
                fileWriter.Close();

                StreamWriter fileWriter2 = new StreamWriter(AppData.DataPath + @"\" + AppData.MovieListFileName, true);
                fileWriter2.WriteLine(movie.ImdbID + ", " +
                            movie.Title + ", " +
                            movie.Released + ", " +
                            movie.Genre + ", " +
                            movie.PlotFileName + ", " +
                            movie.PosterFileName);
                fileWriter.Close();
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }
    }


    //public static async Task<Movie> MovieProcessor(int num)
    //{
    //    int idnum = num;
    //    string url = "";

    //    url = $"http://www.omdbapi.com/?i={ idnum }&apikey=333725e1";

    //    using (HttpResponseMessage response = await Apihelper.ApiClient.GetAsync(url))
    //    {
    //        if (response.IsSuccessStatusCode)
    //        {
    //            Movie movie = await response.Content.ReadAsAsync<Movie>;

    //            return movie;
    //        }
    //        else
    //        {
    //            throw new Exception(response.ReasonPhrase);
    //        }
    //    }
    //}
    }
