﻿using OpenMovieDatabase.Client;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace MovieDataAccessLayer
{
    
    public class Apihelper
    {
        public static HttpClient ApiClient { get; set; }

        public static void InitializeClient()
        {
            ApiClient = new HttpClient();

            OpenMovieDatabaseClient omdbClient = new OpenMovieDatabaseClient("333725e1", ApiClient);

        }

        
     }

    
}
